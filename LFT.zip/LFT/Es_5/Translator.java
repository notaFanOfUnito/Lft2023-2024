import java.io.*;


public class Translator {
    private Lexer lex;
    private BufferedReader pbr;
    private Token look;

    SymbolTable st = new SymbolTable();
    CodeGenerator code = new CodeGenerator();
    int count=0;

    public Translator(Lexer l, BufferedReader br) {
        lex = l;
        pbr = br;
        move();
    }

    void move() {
        look = lex.lexical_scan(pbr);
        System.out.println("token = " + look);
    }

    void error(String s) {
        throw new Error("near line " + Lexer.line + ": " + s);
    }

    void match(int t) {
        if (look.tag == t) {
            if (look.tag != Tag.EOF)
                move();
        } else
            error("syntax error match");
    }

    public void prog() {
        if(look.tag == Tag.ASSIGN || look.tag == Tag.PRINT || look.tag == Tag.READ || look.tag == Tag.FOR
        || look.tag == Tag.IF || look.tag == '{'){
            statlist();
            match(Tag.EOF);
            try {
                code.toJasmin();
            }
            catch(java.io.IOException e) {
                System.out.println("IO error\n");
            };
        }else{
            error("syntax error prog");
        }
    }

    public void statlist() {
        if(look.tag == Tag.ASSIGN || look.tag == Tag.PRINT || look.tag == Tag.READ || look.tag == Tag.FOR
        || look.tag == Tag.IF || look.tag == '{'){
        stat();
        statlistp();
        }else{
            error("syntax error statlist");
        }
    }

    public void statlistp() {
        switch (look.tag) {
            case ';':
                match(';');
                    stat();
                    statlistp();
                break;

            case '}':
            case Tag.EOF: 
                break;

            default: 
                error("syntax error statlistp");
        }

    }

    public void stat() {
            switch (look.tag) {
                case Tag.ASSIGN: 
                    match(Tag.ASSIGN);
                    assignlist(' ');
                    break;
                case Tag.PRINT:
                    match(Tag.PRINT);
                    match('(');
                    exprlist('P');
                    match(')');
                    code.emit(OpCode.invokestatic, 1);
                    break;
                case Tag.READ:
                    match(Tag.READ);
                    match('(');
                    code.emit(OpCode.invokestatic, 0);
                    idlist('R');
                    match(')');
                    break;
                case Tag.FOR:
                    int bexpr_true = code.newLabel();
                    int bexpr_false = code.newLabel();
                    int stat_next = code.newLabel();
                    match(Tag.FOR);
                    match('(');
                    if (look.tag == Tag.ID) {
                        int var_address = st.lookupAddress(((Word)look).lexeme);
                        if (var_address == -1) {
                            var_address = count;
                            st.insert(((Word)look).lexeme,count++);
                        }
                        match(Tag.ID);
                        match(Tag.INIT);
                        expr();
                        code.emit(OpCode.istore, var_address);
                        match(';');
                    }
                    code.emitLabel(stat_next);
                    bexpr(bexpr_true);
                    match(')');
                    code.emit(OpCode.GOto, bexpr_false);
                    code.emitLabel(bexpr_true);
                    match(Tag.DO);
                    stat();
                    code.emit(OpCode.GOto, stat_next);
                    code.emitLabel(bexpr_false);                    
                    break;
                case Tag.IF:
                    int if_bexpr_true = code.newLabel();
                    int if_bexpr_false = code.newLabel();
                    int if_end = code.newLabel();
                    match(Tag.IF);
                    match('(');
                    bexpr(if_bexpr_true);
                    code.emit(OpCode.GOto, if_bexpr_false);
                    match(')');
                    code.emitLabel(if_bexpr_true);
                    stat();
                    code.emit(OpCode.GOto, if_end);
                    code.emitLabel(if_bexpr_false);
                    if (look.tag == Tag.ELSE) {
                    match(Tag.ELSE);
                    stat();
                    }
                    code.emitLabel(if_end);
                    match(Tag.END);
                    break;
                case '{':
                    match('{');
                    statlist();
                    match('}');
                    break;
                default:
                    error("syntax error stat");
            }
    }

    public void idlist(char idlist_i) {
        if (look.tag == Tag.ID) {
            int id_addr = st.lookupAddress(((Word)look).lexeme);
            if (id_addr == -1) {
              id_addr = count;
              st.insert(((Word)look).lexeme,count++);
            }
            match(Tag.ID);
            idlistp(idlist_i);
            code.emit(OpCode.istore,id_addr);
          } else {
            error("Syntax error idlist");
            }
    }

    public void idlistp(char idlistp_i) {
        switch (look.tag) {
            case ',':
              match(',');
              int id_addr = st.lookupAddress(((Word)look).lexeme);
              if (id_addr == -1) {
                id_addr = count;
                st.insert(((Word)look).lexeme,count++);
              }
              match(Tag.ID);
              if (idlistp_i == 'R') {
                code.emit(OpCode.invokestatic,0);
              } else {
                code.emit(OpCode.dup);
              }
              idlistp(idlistp_i);
              code.emit(OpCode.istore,id_addr);
              break;
            case ']':
            case ')':
              break;
            default:
              error("Syntax error idlistp");
          } 
    }

    public void assignlist(char assignlist_i){
        if(look.tag == '['){
            match('[');
            expr();
            match(Tag.TO);
            idlist(' ');
            match(']');
            assignlistp(assignlist_i);
        } else {
            error("syntax error assignlist");
        }
    }

    public void assignlistp(char assignlistp_i){
            switch (look.tag) {
                case '[':
                    match('[');
                    expr();
                    match(Tag.TO);
                    idlist(' ');
                    match(']');
                    assignlistp(assignlistp_i);
                    break;
                case ';':
                case Tag.EOF:
                case '}':
                case Tag.ELSE:
                case Tag.END:
                    break;
                default:
                    error("syntax error assignlistp");
            }
            
    }

    private void bexpr(int bexpr_true) {
        if(look.tag==Tag.RELOP){
            String op = ((Word)look).lexeme;
            match(Tag.RELOP);
            expr();
            expr();
            switch (op) {
                case ">":
                    code.emit(OpCode.if_icmpgt, bexpr_true);
                    break;
                case "<":
                    code.emit(OpCode.if_icmplt, bexpr_true);
                    break;
                
                case "<=":
                    code.emit(OpCode.if_icmple, bexpr_true);
                    break;
                case ">=":
                    code.emit(OpCode.if_icmpgt, bexpr_true);
                    break;

                case "<>":
                    code.emit(OpCode.if_icmpne, bexpr_true);
                    break;
                case "==":
                    code.emit(OpCode.if_icmpeq, bexpr_true);
                    break;
            
                default:
                    break;
            }
        }else{
            error("syntax error bexpr");
        }
    }

    private void expr() {
            switch (look.tag) {
                case '+':
                    match('+');
                    match('(');
                    exprlist('+');
                    match(')');
                    break;
                case '-':
                    match('-');
                    expr();
                    expr();
                    code.emit(OpCode.isub);
                    break;
                case '*':
                    match('*');
                    match('(');
                    exprlist('*');
                    match(')');
                    break;
                case '/':
                    match('/');
                    expr();
                    expr();
                    code.emit(OpCode.idiv);
                    break;
                case Tag.NUM:
                    code.emit(OpCode.ldc, ((NumberTok)look).n);
                    match(Tag.NUM);
                    break;
                case Tag.ID:
                    int id_addr = st.lookupAddress(((Word)look).lexeme);
                    if (id_addr == -1) {
                        error("Variabile " + ((Word)look).lexeme + " Non inizializzata");
                    }
                    code.emit(OpCode.iload, id_addr);
                    match(Tag.ID);
                    break;
                default:
                    error("syntax error expr");
            }
    }

    private void exprlist(char a) {
        if(look.tag == '+' || look.tag == '-' || look.tag == '/' || look.tag == '*' || look.tag == Tag.NUM ||look.tag == Tag.ID){
            expr();
            exprlistp(a);
        } else {
            error("syntax error exprlist");
        }
    }

    private void exprlistp(char a) {
            switch (look.tag) {
                case ',':
                    match(',');
                    switch (a) {
                        case '+':
                            expr();
                            code.emit(OpCode.iadd);
                            break;
                        case '*':
                            expr();
                            code.emit(OpCode.imul);
                            break;

                        case 'P':
                            code.emit(OpCode.invokestatic, 1);
                            expr();
                            break;

                        default:
                        error("syntax error exprlistp");
                    }
                    exprlistp(a);
                    break;
                case ')':
                    break;
                default:
                    error("syntax error exprlistp");
            }
    }

    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = " "; // il percorso del file da leggere
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Translator translator = new Translator(lex, br);
            translator.prog();
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
