import java.io.*;

public class Valutatore {
    private Lexer lex;
    private BufferedReader pbr;
    private Token look;

    public Valutatore(Lexer l, BufferedReader br) {
        lex = l;
        pbr = br;
        move();
    }

    void move() {
        look = lex.lexical_scan(pbr);
        System.out.println("token = " + look);
    }

    void error(String s) {
        throw new Error("linea " + Lexer.line + ": " + s);
    }

    void match(int t) {
        if (look.tag == t) {
            if (look.tag != Tag.EOF)
                move();
        } else
            error("syntax error, match()");
    }

    public void start() {
        int expr_val;
        if (look.tag == Tag.NUM || look.tag == '(') {
            expr_val = expr(); 
            match(Tag.EOF); 
            System.out.println("\n" + "Ris: " + expr_val);
        } else {
            error("Errore start() method"); 
        }
    }

    private int expr() {
        int term_val, exprp_val = 0;
        if (look.tag == '(' || look.tag == Tag.NUM) {
            term_val = term();
            exprp_val = exprp(term_val);
        } else {
            error("Errore expr() method");
        }
        return exprp_val;
    }

    private int exprp(int exprp_i) {
        int term_val, exprp_val = 0;
        if(look.tag == Tag.EOF || look.tag == '+' || look.tag == '-' || look.tag == ')'){
            switch (look.tag) {
                case '+':
                    match('+');
                    term_val = term();
                    exprp_val = exprp(exprp_i + term_val);
                    break;
                case '-':
                    match('-');
                    term_val = term();
                    exprp_val = exprp(exprp_i - term_val);
                    break;
                default:
                    exprp_val = exprp_i;
                    break;
            }
        }else{
            error("Errore exprp() method");
        }
        return exprp_val;
    }

    private int term() {
        int termp_i = 0;
        int termp_val = 0;
        if ( look.tag == '(' || look.tag == Tag.NUM) {
            termp_i = fact();
			termp_val = termp(termp_i);
        } else {
            error("Errore term() method");
        }
        return termp_val;
    }

    private int termp(int termp_i) {
        int fact_val;
        int termp_val = 0;
        if (look.tag == Tag.EOF || look.tag == ')' || look.tag == '*' || look.tag == '/' || look.tag == '+'
                || look.tag == '-') {
            switch (look.tag) {
                case '*':
                    match('*');
                    fact_val = fact();
                    termp_val = termp(termp_i * fact_val);
                    break;
                case '/':
                    match('/');
                    fact_val = fact();
                    termp_val = termp(termp_i / fact_val);
                    break;
                default:
                    termp_val = termp_i;
                    break;
            } 
        } else {
            System.out.println("Errore termp() method, '*' or '/'");
        }
        return termp_val;
    }

    private int fact() {
        int fact_val = 0, expr_val;
        if(look.tag == Tag.NUM){
            switch (look.tag) {
                case '(':
                    match('(');
                    expr_val = expr();
                    if (look.tag == ')') 
                        match(')');
                    else 
                        error("Errore fact()");
                    fact_val = expr_val;
                    break;
                case Tag.NUM:
                    NumberTok x = (NumberTok) look;
                    fact_val = x.n;
                    move();
                    break;
                default:
                    fact_val = 0;
                    break;        
		    }
        }else{
            error("Errore fact() method, '('");
        }
        return fact_val;
    }

    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = " "; // il percorso del file da leggere
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Valutatore valut = new Valutatore(lex, br);
            valut.start();
            System.out.println("OK");
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
