import java.io.*; 

public class Lexer {

    public static int line = 1;
    private char peek = ' ';
    String stringa = "";
    String num = "";
    


    private void readch(BufferedReader br) {
        try {
            peek = (char) br.read();
        } catch (IOException exc) {
            peek = (char) -1; 
        }
    }



    public Token lexical_scan(BufferedReader br) {
        while (peek == ' ' || peek == '\t' || peek == '\n'  || peek == '\r') {
            if (peek == '\n') line++;
            readch(br);
        }

        while(peek=='/'){
			readch(br);
			if(peek=='*'){
				int c=0;
				while(c!=2 && peek!=(char)-1){
					readch(br);
					switch(c){
					case 0:
						if(peek=='*') c=1;
						else c=0;
						break; 
					case 1:
						if(peek=='/'){
							readch(br);
							c=2;
						}
						else if(peek=='*') c=1;
						else c=0;
						break;
					}
				}
				if(c!=2){
					System.err.println("Commento errato: chiusura erronea");
		               		return null;
		        }   	
			}else if(peek=='/'){
				while(peek!=10 && peek!=(char)-1){
					readch(br);
				}
			}else{
				return Token.div;
			}
            while (peek == ' ' || peek == '\t' || peek == '\n'  || peek == '\r') {
                if (peek == '\n') line++;
                readch(br);
            }
		}
        
        switch (peek) {
            case '!':
                peek = ' ';
                return Token.not;

            case '(':
                peek = ' ';
                return Token.lpt;

            case ')':
                peek = ' ';
                return Token.rpt;

            case '[':
                peek = ' ';
                return Token.lpq;

            case ']':
                peek = ' ';
                return Token.rpq;

            case '{':
                peek = ' ';
                return Token.lpg;

            case '}':
                peek = ' ';
                return Token.rpg;

            case '+':
                peek = ' ';
                return Token.plus;

            case '-':
                peek = ' ';
                return Token.minus;

            case '*':
                peek = ' ';
                return Token.mult;


            case ';':
                peek = ' ';
                return Token.semicolon;

            case ',':
                peek = ' ';
                return Token.comma;

	// ... gestire i casi di ( ) [ ] { } + - * / ; , ... //
	
            case '&':
                readch(br);
                if (peek == '&') {
                    peek = ' ';
                    return Word.and;
                } else {
                    System.err.println("Carattere errato"
                            + " dopo & : "  + peek );
                    return null;
                }
            
                case '|':
                readch(br);
                if (peek == '|') {
                    peek = ' ';
                    return Word.or;
                } else {
                    System.err.println("Carattere errato"
                            + " dopo | : "  + peek );
                    return null;
                }

            case '<':
                readch(br);
                if (peek == '=') {
                    peek = ' ';
                    return Word.le;
                }else if (peek == '>') {
                    peek = ' ';
                    return Word.ne;
                } else {
                    return Word.lt;
                }

            case '>':
                readch(br);
                if (peek == '=') {
                    peek = ' ';
                    return Word.ge;
                } else {
                    return Word.gt;
                }

            case '=':
                readch(br);
                if (peek == '=') {
                    peek = ' ';
                    return Word.eq;
                } else {
                    System.err.println("Carattere errato"
                            + " dopo = : "  + peek );
                    return null;
                }

	// ... gestire i casi di || < > <= >= == <> ... //
          
            case (char)-1:
                return new Token(Tag.EOF);

            default:
                if (Character.isLetter(peek)) {

                    String lex = "";
                    int s=0;
                    while (Character.isLetter(peek) || Character.isDigit(peek) || peek=='_'){
                        lex=lex+peek;
                        switch(s){
                            case 0:
                                if(peek=='_') s=0; 
                                else s=1;
                            case 1:
                        }
                        readch(br); 
                    }
                    if(s==0){
                    	System.err.println("identificatore sbagliato");
                    	return null;
                    }
                    switch (lex) {
                        case "assign":
                            return Word.assign;
                        case "to":
                            return Word.to;
                        case "do":
                            return Word.dotok;
                        case "if":
                            return Word.iftok;
                        case "read":
                            return Word.read;
                        case "print":
                            return Word.print;
                        case "else":
                            return Word.elsetok;
                        case "end":
                            return Word.end;
                        case "for":
                            return Word.fortok;
                        case "begin":
                            return Word.begin;
                        case "init":
                            return Word.init;
                        default:	return new Word(Tag.ID, lex);
                    }  

                } else if (Character.isDigit(peek)) {
                    while (Character.isDigit(peek)) {
                        num = num + peek;
                        readch(br);
                    }
                    String x = num;
                    num = "";
                    return new NumberTok(Integer.parseInt(x));

                } else if (peek == '_') {
                    while (Character.isDigit(peek) || Character.isLetter(peek) || peek == '_') {
                        stringa = stringa + peek;
                        readch(br);
                    }
                    String x = stringa;
                    stringa = "";
                    return new Word(Tag.ID, x);
                } else {
                    System.err.println("Carattere errato: "
                            + peek);
                    return null;
                }
         }
    }
		
    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = " "; // il percorso del file da leggere
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Token tok;
            do {
                tok = lex.lexical_scan(br);
                System.out.println("Scan: " + tok);
            } while (tok.tag != Tag.EOF);
            br.close();
        } catch (IOException e) {e.printStackTrace();}    
    }

}
