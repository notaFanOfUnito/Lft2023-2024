import java.io.*;


public class Parser {
    private Lexer lex;
    private BufferedReader pbr;
    private Token look;

    public Parser(Lexer l, BufferedReader br) {
        lex = l;
        pbr = br;
        move();
    }

    void move() {
        look = lex.lexical_scan(pbr);
        System.out.println("token = " + look);
    }

    void error(String s) {
        throw new Error(" linea " + Lexer.line + ": " + s);
    }

    void match(int t) {
        if (look.tag == t) {
            if (look.tag != Tag.EOF)
                move();
        } else
            error("syntax error");
    }

    public void prog() {
        if(look.tag == Tag.ASSIGN || look.tag == Tag.PRINT || look.tag == Tag.READ || look.tag == Tag.FOR
        || look.tag == Tag.IF || look.tag == '{'){
            statlist();
            match(Tag.EOF);
        }else{
            error("syntax error prog");
        }
    }

    public void statlist() {
        if(look.tag == Tag.ASSIGN || look.tag == Tag.PRINT || look.tag == Tag.READ || look.tag == Tag.FOR
        || look.tag == Tag.IF || look.tag == '{'){
        stat();
        statlistp();
        }else{
            error("syntax error statlist");
        }
    }



    public void statlistp() {
        switch (look.tag) {
            case ';':
                match(';');
                    stat();
                    statlistp();
                break;

            case '}':
            case Tag.EOF: 
                break;

            default: 
                error("syntax error statlistp");
        }

    }



    public void stat() {
            switch (look.tag) {
                case Tag.ASSIGN: 
                    match(Tag.ASSIGN);
                    assignlist();
                    break;
                case Tag.PRINT:
                    match(Tag.PRINT);
                    match('(');
                    exprlist();
                    match(')');
                    break;
                case Tag.READ:
                    match(Tag.READ);
                    match('(');
                    idlist();
                    match(')');
                    break;
                case Tag.FOR:
                    match(Tag.FOR);
                    match('(');
                    if (look.tag == Tag.ID) {
                        match(Tag.ID);
                        match(Tag.INIT);
                        expr();
                        match(';');
                    }
                    bexpr();
                    match(')');
                    match(Tag.DO);
                    stat();                    
                    break;
                case Tag.IF:
                    match(Tag.IF);
                    match('(');
                    bexpr();
                    match(')');
                    stat();
                    if (look.tag == Tag.ELSE) {
                        match(Tag.ELSE);
                        stat();
                    }
                    match(Tag.END);
                    break;
                case '{':
                    match('{');
                    statlist();
                    match('}');
                    break;
                default:
                    error("syntax error stat");
            }
    }



    public void idlist() {
        if(look.tag == Tag.ID){
            match(Tag.ID);
            idlistp();
        }else{
            error("syntax error idlist");
        }
    }



    public void idlistp() {
            switch (look.tag) {
                case ',':
                    match(',');
                    match(Tag.ID);
                    idlistp();
                case ']':
                case ')':
                    break;
                default:
                    error("syntax error idlistp");
            }
           
    }



    public void assignlist(){
        if(look.tag == '['){
            match('[');
            expr();
            match(Tag.TO);
            idlist();
            match(']');
            assignlistp();
        } else {
            error("syntax error assignlist");
        }
    }



    public void assignlistp(){
            switch (look.tag) {
                case '[':
                    match('[');
                    expr();
                    match(Tag.TO);
                    idlist();
                    match(']');
                    assignlistp();
                    break;
                case ';':
                case Tag.EOF:
                case '}':
                case Tag.ELSE:
                case Tag.END:
                    break;
                default:
                    error("syntax error assignlistp");
            }
            
    }

    private void bexpr() {
        if(look.tag==Tag.RELOP){
            match(Tag.RELOP);
            expr();
            expr();
        }else{
            error("syntax error bexpr");
        }
    }

    private void expr() {
            switch (look.tag) {
                case '+':
                    match('+');
                    match('(');
                    exprlist();
                    match(')');
                    break;
                case '-':
                    match('-');
                    expr();
                    expr();
                    break;
                case '*':
                    match('*');
                    match('(');
                    exprlist();
                    match(')');
                    break;
                case '/':
                    match('/');
                    expr();
                    expr();
                    break;
                case Tag.NUM:
                    match(Tag.NUM);
                    break;
                case Tag.ID:
                    match(Tag.ID);
                    break;
                default:
                    error("syntax error expr");
            }
    }

    private void exprlist() {
        if(look.tag == '+' || look.tag == '-' || look.tag == '/' || look.tag == '*' || look.tag == Tag.NUM ||look.tag == Tag.ID){
            expr();
            exprlistp();
        } else {
            error("syntax error exprlist");
        }
    }

    private void exprlistp() {
            switch (look.tag) {
                case ',':
                    match(',');
                    expr();
                    exprlistp();
                    break;
                case ')':
                    break;
                default:
                    error("syntax error exprlistp");
            }
    }

    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = " "; // il percorso del file da leggere
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Parser parser = new Parser(lex, br);
            parser.prog();
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
